
x = int(input("Ingrese La Nota del Estudiante: "))

if x >= 75:
  print("O")
elif x >=60 and x <= 74:
  print("A")
elif x >= 50 and x <= 59:
  print("B")
elif x >=40 and x <= 49:
  print("C")
elif x <= 40:
  print("D")