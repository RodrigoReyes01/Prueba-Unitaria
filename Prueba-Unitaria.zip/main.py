from Funcion import Nota_estudiante

x = input("Ingrese la nota del estudiante: ")
notafinal = Nota_estudiante(x)

print(notafinal)